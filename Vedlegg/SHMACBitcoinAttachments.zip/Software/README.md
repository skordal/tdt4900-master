The SHMAC Bitcoin Miner
=======================

This directory contains the source code for the SHMAC bitcoin miner.

It is a work in progress and will be committed to the SHMAC Mercurial repository when it works.

